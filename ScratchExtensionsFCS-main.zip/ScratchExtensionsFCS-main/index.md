<h1>FCS Scratch Extensions - Hosting on Github</h1>

Have fun trying our extensions!

Utils - https://turbowarp.org/editor?extension=https://familycomicsstudios.github.io/ScratchExtensionsFCS/Code/utils.js

Math + Utils - https://turbowarp.org/editor?extension=https://familycomicsstudios.github.io/ScratchExtensionsFCS/Code/utils.js&extension=https%3A%2F%2Ffamilycomicsstudios.github.io%2FScratchExtensionsFCS%2FCode%2Fscratchmath.js
